<?php
include '../common.php';

$bookingCalendarObj->setDefaultCalendar($_GET["calendar_id"],$_GET["category_id"]);

?>